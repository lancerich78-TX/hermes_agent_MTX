#!/usr/bin/env python3
"""Build an Electra Link-branded AV Scope of Work (.docx, optional .pdf) from a JSON project file.

Usage:
    python build_sow.py project_sow.json [-o OUTPUT.docx] [--pdf] [--logo LOGO.png]

All project data lives in the JSON input (see templates/sow_input.example.json).
Requires: python-docx (pip install python-docx). --pdf needs LibreOffice (soffice on PATH or in its default install folder).

Document structure (follows the Electra Link 'Scope of Work/Assumptions/Notes' section):
  header (logo, company block, project block) / red title band / SCOPE OF WORK + project info table
  PROJECT OVERVIEW, GENERAL REQUIREMENTS, DECOMMISSION
  per room (grey band): INSTALLATION (narrative paragraph, then '-Provide and install...' lines
      with indented '*' sub-notes, then '-Utilize TP-01 to control...' with '*' functions),
      OWNER RESPONSIBILITIES, CABLING AND INFRASTRUCTURE, PROGRAMMING AND CONFIGURATION,
      TESTING AND COMMISSIONING
  TRAINING, DOCUMENTATION / AS-BUILTS, WARRANTY, EXCLUSIONS, ASSUMPTIONS (short paragraphs),
  [MANUFACTURER SOURCES], OPEN ITEMS / TBD table, closing change-order line
  footer: date (MM/DD/YY) + 'Page X of Y'
"""
import argparse
import datetime as dt
import json
import os
import shutil
import subprocess
import sys

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_LOGO = os.path.join(HERE, '..', 'assets', 'electra-link-logo.png')

# ---- Brand config / standard text (override any of these in the JSON) -----
BAND_RED, BAND_GREY, HEAD_GREY = 'F25A5A', 'D9D9D9', 'F2F2F2'
DEFAULT_COMPANY = {
    'name': 'Electra Link, Inc.', 'abbr': 'ELI',
    'address_lines': ['21755 IH-45, Bldg. #10', 'Spring, TX 77388'], 'phone': 'P (281) 350-6096',
}
WARRANTY_INTRO = 'Standard One Year Workmanship Warranty is included and is defined below:'
WARRANTY_TEXT = (
    '{name} ({abbr}) warrants its installation services will be free of defects in workmanship, parts and materials '
    'for a period of one (1) year. This warranty period will begin at the earlier of the completion of the installation or the '
    'first substantial use of the equipment. In addition, the equipment may be subject to manufacturers\' limited warranties '
    'varying in length. These warranties do not apply in the event of misuse, neglect, accident, or operation errors. Any work '
    'performed by {name} outside of the scope of these warranties or performed on owner supplied equipment will be '
    'separately charged.')
WARRANTY_OFE = ('On equipment furnished by the owner{ofe}, we cannot warranty this equipment without an additional service '
                'contract. We will, however during the installation, test and adjust the equipment as necessary for the best possible performance.')
DEFAULT_GENERAL = [
    'Furnish all equipment listed as contractor-furnished on the Bill of Materials, new and in manufacturer packaging.',
    'Verify owner-furnished equipment, mounting locations and cable pathways at a site survey before ordering.',
    'Submit equipment list and product data for approval; confirm all TBD items (see Open Items) before construction.',
    'Install all work in a neat and workmanlike manner per manufacturer instructions, NEC and local codes, and ANSI/TIA cabling practice.',
    'Label all cables at both ends with unique project-wide IDs conforming to AVIXA F501.01, per the drawing general notes.',
    'Use plenum-rated cable where run in air-handling spaces; support cable independently of ceiling grid.',
    'Coordinate network ports, VLANs, IP addressing and security requirements with owner IT prior to programming.',
    'Coordinate with the owner and other trades; protect finishes and clean up work areas daily.',
]
DEFAULT_ASSUMPTIONS = [
    'The electrical power system necessary to power the listed equipment will be provided and installed by others and will be available throughout the duration of this project.',
    'The empty conduit system, back boxes and table/floor penetrations into which the audio, video, and control cabling is to be installed will be provided by others. Cable included in this scope is plenum-rated where required.',
    'Owner IT will provide network ports, VLAN and IP information, and any conferencing resource accounts before programming begins.',
    'Pricing is based on normal business hours, 7:00 am - 3:30 pm. Any work performed after normal business hours, or outside this scope of work, will require a change order signed by an authorized customer contact.',
    'Cable lengths are not shown on functional drawings; cabling quantities will be confirmed at the site survey.',
    'Customer will provide access badges, keys and/or escorts as required, a designated project contact, and an area for storage of materials.',
    '{abbr} will clean up and restore all areas each day before leaving the site.',
]
CLOSING = 'Any work performed outside this scope of work will require a change order signed by an authorized customer contact for approval.'


class SOW:
    def __init__(self, cfg, logo):
        self.cfg, self.logo = cfg, logo
        self.co = {**DEFAULT_COMPANY, **cfg.get('company', {})}
        self.doc = Document()
        self._setup()

    # ---------- low-level helpers ----------
    @staticmethod
    def shade(cell, color):
        tcPr = cell._tc.get_or_add_tcPr()
        s = OxmlElement('w:shd')
        s.set(qn('w:val'), 'clear'); s.set(qn('w:color'), 'auto'); s.set(qn('w:fill'), color)
        tcPr.append(s)

    @staticmethod
    def no_borders(tbl):
        b = OxmlElement('w:tblBorders')
        for e in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
            x = OxmlElement(f'w:{e}'); x.set(qn('w:val'), 'nil'); b.append(x)
        tbl._tbl.tblPr.append(b)

    @staticmethod
    def field(run, code):
        f1 = OxmlElement('w:fldChar'); f1.set(qn('w:fldCharType'), 'begin')
        it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = code
        f2 = OxmlElement('w:fldChar'); f2.set(qn('w:fldCharType'), 'end')
        run._r.append(f1); run._r.append(it); run._r.append(f2)

    @staticmethod
    def setw(tb, widths):
        tb.autofit = False
        for i, w in enumerate(widths):
            tb.columns[i].width = Inches(w)
            for row in tb.rows:
                row.cells[i].width = Inches(w)

    def fmt(self, text):
        return text.replace('{abbr}', self.co['abbr']).replace('{name}', self.co['name'])

    # ---------- page setup, header, footer ----------
    def _setup(self):
        doc, p = self.doc, self.cfg['project']
        sec = doc.sections[0]
        sec.page_width, sec.page_height = Inches(8.5), Inches(11)
        sec.left_margin = sec.right_margin = Inches(0.75)
        sec.top_margin, sec.bottom_margin = Inches(0.6), Inches(0.7)
        sec.header_distance, sec.footer_distance = Inches(0.3), Inches(0.35)
        st = doc.styles['Normal']
        st.font.name, st.font.size = 'Arial', Pt(10)
        st.element.rPr.rFonts.set(qn('w:eastAsia'), 'Arial')
        pf = st.paragraph_format
        pf.space_after = pf.space_before = Pt(0); pf.line_spacing = 1.0

        hdr = sec.header
        hp = hdr.paragraphs[0]
        t = hdr.add_table(rows=1, cols=3, width=Inches(7.0)); self.no_borders(t)
        c0, c1, c2 = t.rows[0].cells
        self.setw(t, [1.6, 2.4, 3.0])
        if self.logo and os.path.exists(self.logo):
            c0.paragraphs[0].add_run().add_picture(self.logo, width=Inches(1.35))
        left = [self.co['name']] + self.co['address_lines'] + [self.co['phone']]
        right = [f"{p['doc_set']}  |  Scope of Work", p.get('rooms_line', ''),
                 f"Owner: {p.get('owner', 'TBD')}  |  Project No.: {p.get('project_no', 'TBD')}",
                 f"Address: {p.get('address', 'TBD')}"]
        for cell, lines, align in ((c1, left, None), (c2, right, WD_ALIGN_PARAGRAPH.RIGHT)):
            para = cell.paragraphs[0]
            if align is not None:
                para.alignment = align
            for i, line in enumerate(lines):
                r = para.add_run(line + ('\n' if i < len(lines) - 1 else ''))
                r.font.size, r.bold = Pt(8), (i == 0)
        hp._p.getparent().remove(hp._p)

        grey = RGBColor(0x66, 0x66, 0x66)
        fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        d = p.get('date')
        dstr = dt.date.fromisoformat(d).strftime('%m/%d/%y') if d else dt.date.today().strftime('%m/%d/%y')
        for text, code in ((dstr + ' ' * 62 + 'Page ', None), (None, 'PAGE'), (' of ', None), (None, 'NUMPAGES')):
            r = fp.add_run(text or '')
            r.font.size, r.font.color.rgb = Pt(8), grey
            if code:
                self.field(r, code)

    # ---------- content helpers ----------
    def band(self, text, color=BAND_RED, size=11, before=False):
        if before:
            self.doc.add_paragraph()
        tb = self.doc.add_table(rows=1, cols=1); tb.alignment = WD_TABLE_ALIGNMENT.CENTER
        c = tb.rows[0].cells[0]; self.shade(c, color); c.width = Inches(7.0)
        para = c.paragraphs[0]; para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = para.add_run(text); r.bold = True; r.font.size = Pt(size)
        self.doc.add_paragraph()

    def H(self, text, before=8):
        para = self.doc.add_paragraph()
        para.paragraph_format.space_before, para.paragraph_format.space_after = Pt(before), Pt(6)
        para.paragraph_format.keep_with_next = True
        para.add_run(text.upper()).bold = True

    def P(self, text, after=6):
        para = self.doc.add_paragraph(self.fmt(text)); para.paragraph_format.space_after = Pt(after)
        return para

    def D(self, text):
        return self.doc.add_paragraph('-' + self.fmt(text))

    def S(self, text):
        para = self.doc.add_paragraph('*' + self.fmt(text)); para.paragraph_format.left_indent = Inches(0.35)
        return para

    def items(self, lst):
        """List entries: "text" -> '-text'; {"text":..., "notes":[...]} -> '-text' + '*note' lines."""
        for it in lst or []:
            if isinstance(it, str):
                self.D(it)
            else:
                self.D(it['text'])
                for n in it.get('notes', []):
                    self.S(n)

    def text_or_items(self, v):
        if isinstance(v, str):
            self.P(v)
        else:
            self.items(v)

    # ---------- document ----------
    def build(self):
        c, p = self.cfg, self.cfg['project']
        self.band('Scope of Work/Assumptions/Notes')
        para = self.doc.add_paragraph(); para.add_run('SCOPE OF WORK').bold = True
        para.paragraph_format.space_after = Pt(6)
        info = p.get('info') or [
            ('Project', f"{p['doc_set']} - {p.get('title', '')}"),
            ('Owner / Address', f"{p.get('owner', 'TBD')} / {p.get('address', 'TBD')}"),
            ('Project Number', p.get('project_no', 'TBD')),
            ('Prepared by', p.get('prepared_by', 'TBD')),
            ('Date', dt.date.fromisoformat(p['date']).strftime('%B %d, %Y') if p.get('date') else 'TBD'),
            ('Basis of Scope', p.get('basis', 'TBD')),
        ]
        tb = self.doc.add_table(rows=len(info), cols=2); tb.style = 'Table Grid'
        for i, (k, v) in enumerate(info):
            a, b = tb.rows[i].cells; self.shade(a, HEAD_GREY)
            ra = a.paragraphs[0].add_run(k); ra.bold = True; ra.font.size = Pt(9)
            b.paragraphs[0].add_run(v).font.size = Pt(9)
        self.setw(tb, [1.6, 5.4])
        self.doc.add_paragraph()

        self.H('Project Overview', 4); self.text_or_items(c.get('overview', 'TBD'))
        self.H('General Requirements'); self.items(c.get('general_requirements', DEFAULT_GENERAL))
        self.H('Decommission'); self.text_or_items(c.get('decommission',
               'No removal of existing AV equipment is indicated on the drawings. Any decommissioning identified at the site survey will be handled by change order.'))

        for room in c['rooms']:
            self.band(room.get('heading', f"ROOM {room['name']}"), BAND_GREY, 10, True)
            self.H('Installation', 0)
            if room.get('installation_narrative'):
                self.P(room['installation_narrative'])
            self.items(room.get('installation'))
            ctl = room.get('control')
            if ctl:
                self.D(ctl.get('intro', f"Utilize {ctl.get('panel', 'TP-01')} to control all conferencing functions as well as the following AV functions:"))
                for fn in ctl.get('functions', []):
                    self.S(fn)
            for key, title in (('owner_responsibilities', 'Owner Responsibilities'),
                               ('cabling', 'Cabling and Infrastructure'),
                               ('programming', 'Programming and Configuration'),
                               ('testing', 'Testing and Commissioning')):
                if room.get(key):
                    self.H(title); self.text_or_items(room[key])

        self.H('Training'); self.text_or_items(c.get('training', 'TBD'))
        self.H('Documentation / As-Builts'); self.text_or_items(c.get('documentation', [
            'As-built drawings and cable schedule with AVIXA F501.01 cable IDs.',
            'Equipment list with serial numbers, MAC and IP addresses, firmware versions and device credentials (delivered securely).',
            'Final configuration and programming files for all configurable devices.',
            'Manufacturer manuals and warranty information.']))
        self.H('Warranty')
        w = c.get('warranty', {})
        self.P(w.get('intro', WARRANTY_INTRO))
        self.P(w.get('text', WARRANTY_TEXT))
        ofe = w.get('ofe_items')
        self.P(w.get('ofe_text', WARRANTY_OFE.replace('{ofe}', f" (including {ofe})" if ofe else '')))
        self.H('Exclusions'); self.items(c.get('exclusions', []))
        self.H('Assumptions')
        for t in c.get('assumptions', DEFAULT_ASSUMPTIONS):
            self.P(t)
        if c.get('sources'):
            self.H(c.get('sources_title', 'Manufacturer Sources'))
            self.items(c['sources'])
        self.H('Open Items / TBD')
        self.P(c.get('open_items_intro', 'The following items are marked TBD on the drawings and must be resolved before construction:'), 4)
        tb = self.doc.add_table(rows=1, cols=3); tb.style = 'Table Grid'
        for i, h in enumerate(['#', 'Room', 'Open Item']):
            cell = tb.rows[0].cells[i]; self.shade(cell, BAND_GREY)
            r = cell.paragraphs[0].add_run(h); r.bold = True; r.font.size = Pt(9)
        th = OxmlElement('w:tblHeader'); th.set(qn('w:val'), 'true')
        tb.rows[0]._tr.get_or_add_trPr().append(th)
        for n, oi in enumerate(c.get('open_items', []), 1):
            row = tb.add_row().cells
            for i, v in enumerate([str(n), oi.get('room', ''), oi['item']]):
                row[i].paragraphs[0].add_run(v).font.size = Pt(9)
        self.setw(tb, [0.4, 0.7, 5.9])
        self.doc.add_paragraph()
        self.P(c.get('closing', CLOSING))
        return self.doc


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('input', help='project SOW JSON file')
    ap.add_argument('-o', '--output', help='output .docx (default: <doc_set>-Scope-of-Work.docx next to the input)')
    ap.add_argument('--pdf', action='store_true', help='also export a PDF with LibreOffice (soffice)')
    ap.add_argument('--logo', help='logo PNG (default: ../assets/electra-link-logo.png)')
    a = ap.parse_args()
    with open(a.input, encoding='utf-8') as fh:
        cfg = json.load(fh)
    out = a.output or cfg.get('output') or os.path.join(os.path.dirname(os.path.abspath(a.input)),
                                                        f"{cfg['project']['doc_set']}-Scope-of-Work.docx")
    SOW(cfg, a.logo or cfg.get('logo') or DEFAULT_LOGO).build().save(out)
    print(f"Wrote {out}")
    if a.pdf:
        exe = shutil.which('soffice') or shutil.which('libreoffice') or shutil.which('soffice.exe')
        if not exe:
            for cand in (r'C:\Program Files\LibreOffice\program\soffice.exe',
                         r'C:\Program Files (x86)\LibreOffice\program\soffice.exe',
                         '/Applications/LibreOffice.app/Contents/MacOS/soffice'):
                if os.path.exists(cand):
                    exe = cand
                    break
        if not exe:
            print('WARNING: LibreOffice (soffice) not found; PDF not created', file=sys.stderr)
            return 1
        subprocess.run([exe, '--headless', '--convert-to', 'pdf', '--outdir',
                        os.path.dirname(os.path.abspath(out)), out], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=300)
        print(f"Wrote {os.path.splitext(out)[0]}.pdf")
    return 0


if __name__ == '__main__':
    sys.exit(main())
