---
name: av-scope-of-work
description: "Use this when writing or updating an Electra Link AV Scope of Work (editable Word .docx, optional PDF) from AV drawings and the BoM, in the Scope of Work/Assumptions/Notes format with per-room installation, programming, testing, warranty, assumptions and open items, plus design-package zips."
version: 0.1.0
author: Lance Richards (Electra Link), CTS-D
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [av, audiovisual, scope-of-work, sow, docx, proposal, electra-link]
    related_skills: [av-signal-flow, av-bill-of-materials, docx, pdf]
---

# AV Scope of Work (Electra Link)

Build an editable Word Scope of Work (.docx, optional PDF) in the Electra Link "Scope of Work/Assumptions/Notes" format. Content comes only from the project drawings, the BoM and manufacturer documentation.

Supporting files live beside this skill (paths are relative to the skill folder):
- `scripts/build_sow.py`: generator. All project content comes from a JSON input file. Brand colors, company block, the standard one-year workmanship warranty and the default general requirements/assumptions are in the config block at the top, and the JSON can override any of them.
- `templates/sow_input.example.json`: input template.
- `scripts/package_deliverables.py` + `templates/package_input.example.json`: builds the per-solution deliverable folders, README and zip.
- `assets/electra-link-logo.png`: header logo.

Related skills: `av-signal-flow` (drawings, same tags) and `av-bill-of-materials` (the BoM built from the same inventory; the SOW names the same equipment).

## When to Use

- The user wants a scope of work, SOW, installation scope or "Scope of Work/Assumptions/Notes" for an AV project
- Updating a SOW after a drawing or BoM revision
- Building a multi-brand design package (one SOW per branded solution)

## Format (produced by the script)

Follows the structure of Electra Link's Scope of Work/Assumptions/Notes section only (no pricing, payment terms or legal pages):

- **Header:** logo, Electra Link company block, project block (doc set | Scope of Work, rooms, owner / project no., address). **Footer:** date `MM/DD/YY` and `Page X of Y`.
- **Red title band** "Scope of Work/Assumptions/Notes", then **SCOPE OF WORK** and a project info table (project, owner/address, project number, prepared by, date, basis of scope).
- **Headings:** bold, all caps.
- **Section order:**
  1. PROJECT OVERVIEW, GENERAL REQUIREMENTS, DECOMMISSION
  2. For each room (grey band with room name and drawing/revision):
     - **INSTALLATION**: a narrative paragraph describing how the room is used, then `-Provide and install a <Mfr> <Model> <description> (<TAG>).` lines with indented `*` sub-notes (mounting, connections, what's included), then `-Utilize TP-01 to control all ... as well as the following AV functions:` with indented `*` functions
     - OWNER RESPONSIBILITIES, CABLING AND INFRASTRUCTURE, PROGRAMMING AND CONFIGURATION, TESTING AND COMMISSIONING
  3. TRAINING, DOCUMENTATION / AS-BUILTS, WARRANTY, EXCLUSIONS, ASSUMPTIONS, optional MANUFACTURER SOURCES, OPEN ITEMS / TBD table (#, Room, Open Item)
  4. Closing change-order sentence
- **Warranty:** the Electra Link Standard One Year Workmanship Warranty text plus the owner-furnished-equipment paragraph (script default; `warranty.ofe_items` names the OFE items).
- **Assumptions:** short standalone paragraphs, not bullets.

## Rules

1. **Source every statement.** Equipment, quantities, tags, connections and control functions come from the drawings and the BoM. Capabilities, mounting and in-box contents come from manufacturer docs. Don't add equipment or features that aren't on the drawings.
2. **Same inventory as the BoM:** identical tags, models and quantities. OFE items are "Install owner-furnished ..." lines, not "Provide and install".
3. Every drawing TBD or unverified BoM item appears in the **Open Items** table, with its keynote reference where there is one.
4. Use "Provide and install" for contractor-furnished equipment, "Provide ... to be installed by others" where applicable, and "Install" for owner-furnished items. Keep sub-notes short and factual.
5. Keep the standard warranty text word-for-word unless the user supplies a different one.

## Procedure

1. **Gather inputs:** latest drawing revisions (keynotes and general notes), the BoM (`av-bill-of-materials`), manufacturer docs for configuration/programming facts (pairing, licensing, network/AES67/Dante requirements, AEC reference routing).
2. **Fill the JSON** from `templates/sow_input.example.json`:
   - `project` and `overview`
   - `rooms[]`, each with `installation_narrative`, `installation` (strings, or `{text, notes[]}` for `*` sub-notes), `control` (`panel`, `intro`, `functions[]`), `owner_responsibilities`, `cabling`, `programming` and `testing`
   - project-level `training`, `documentation`, `exclusions`, `assumptions`, `sources` and `open_items`
   - leave out `general_requirements`, `assumptions` and `documentation` to use the Electra Link defaults
3. **Run:** `python scripts/build_sow.py <input>.json -o <DOCSET>-Scope-of-Work.docx --pdf`. `--pdf` needs LibreOffice (`soffice`).
4. **Check:** render the PDF and confirm the title band, header/footer, `Page X of Y`, section order, `-` / `*` indentation, and that the open-items table covers every TBD. Re-read it against the drawings: same tags, same devices, nothing invented.
5. **Deliver.** Write the input JSON with `write_file`, run the script from the terminal, then show the result with `::preview{file="..."}` on its own line (preview the PDF render for a visual check; the .docx document is the deliverable). Report TBD/open-item counts.

## Packaging a design package

1. One folder per branded solution (for example `Crestron/`, `QSC-Q-SYS/`), each with `Drawings/` (PDF), `BoM/` (xlsx) and `Scope of Work/` (docx). Latest revisions only.
2. Fill `templates/package_input.example.json` and run `python scripts/package_deliverables.py package.json -o <outdir>`. It copies the files, writes `README.txt` and zips the package.

## Pitfalls

- Copying pricing, payment terms or legal boilerplate from the example proposal into the SOW
- Describing equipment or functions that aren't on the drawings
- SOW tags, models or quantities that disagree with the BoM
- Converting assumptions to bullet lists, or losing the `-` / `*` style
- TBDs mentioned in the body but missing from the Open Items table

## Output paths

Save under the project folder if the user has one, else the current working directory:

```
<DOCSET>-Scope-of-Work.docx
<DOCSET>-Scope-of-Work.pdf     (optional)
<DOCSET>-sow-input.json        (keep it; re-run after revisions)
```

Requirements: Python 3 with `python-docx` (`pip install python-docx`). LibreOffice (`soffice`) is needed only for `--pdf` (on Windows add its `program` folder to PATH).
