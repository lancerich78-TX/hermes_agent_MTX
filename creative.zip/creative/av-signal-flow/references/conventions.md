# AV drawing conventions

Standards basis (house standards and project/owner CAD standards override this file):

- **AIA side:** United States National CAD Standard (NCS, published by NIBS; current is **V7, Sept 2025**). It contains the **AIA CAD Layer Guidelines (CLG)**, CSI's **Uniform Drawing System (UDS)**, and the **Plotting Guidelines**.
- **AVIXA side:** **ANSI/AVIXA D401.01:2023** *Documentation Requirements for Audiovisual Systems* (formerly INFOCOMM 2M-2010), **AVIXA F501.01:2015** *Cable Labeling for Audiovisual Systems* (formerly INFOCOMM F501.01; AVIXA publishes it without the ANSI prefix), and **ANSI/J-STD-710** *Audio, Video and Control Architectural Drawing Symbols* (CTA/CEDIA/AVIXA, 2015).
- Tags below: **[NCS]**, **[D401]**, **[F501]**, **[710]** = from that standard (checked against public excerpts; see "Sources"). **[house]** = common practice or this skill's own convention, not from a standard.

## Drawing types (pick one per sheet)

| Type | Question it answers | Show | Typical NCS sheet |
|---|---|---|---|
| Functional / block | How subsystems relate | Named buses, not every patch | TA6xx |
| Signal flow / wiring | What connects to what, and with which cable | Every active cable, ports, IDs | TA6xx |
| Riser | How signals travel between floors/rooms | Backbone only, room nodes | TA6xx |
| Control architecture | Who talks to whom | IP, RS-232, GPIO, IR, relays | TA6xx |

Never put a floor plan on these sheets. Device locations belong on TA1xx plans with J-STD-710 symbols.

## AIA / NCS

### Sheet identification [NCS UDS Module 1]
- Format: discipline designator (1 letter + hyphen, or 2 letters) + sheet type digit + 2-digit sequence number.
- **AV = `TA`**, the Level 2 designator "Telecommunications – Audio Visual". No hyphen goes after a Level 2 designator, so AV sheets are `TA601`, not `TA-601`. The Level 1 alternative is `T-601` when AV is combined with other telecom. `AV-…` is **not** an NCS designator. Use it only if the project standard demands it.
- Sheet types: 0 General (symbols legend, notes), 1 Plans, 2 Elevations, 3 Sections, 4 Large-scale views, 5 Details, **6 Schedules and Diagrams**, 7–8 User defined, 9 3D.
- Sequence numbers start at 01 (00 is not allowed) and may skip to leave room for inserts.
- AV mapping [house, built on NCS types]:
  - `TA001` legend/abbreviations/general notes
  - `TA101…` AV plans and RCP device layouts
  - `TA201…` rack and wall elevations
  - `TA501…` details (plates, mounts)
  - `TA601…` signal flow, functional, riser, and control diagrams
  - `TA611…` cable/equipment schedules, if you split them out
- Supplemental reissue suffix: `-R1` = revised, `-X1` = complete change, `-A1` = phase.
- A single room package still uses `TA601`. Number additional rooms `TA602`, `TA603`…

### Sheet size [NCS UDS 2.2]
- UDS sheet sizes:
  - ANSI D = 22×34 in; ARCH D = 24×36 in
  - ANSI E = 34×44 in; ARCH E = 36×48 in
  - ANSI/ARCH B (11×17 / 12×18) for half-size reductions
- Default: **ARCH D 36×24 landscape** [house]. Use ANSI D when the architect's set does. Always match the architect's sheet size.
- Practical minimum margins [NCS]: top/bottom 3/4 in, **left 1-1/2 in** (binding), right 3/4 in.

### Sheet layout [NCS UDS 2.3]
- A sheet has a drawing area and a title block area (both required), plus an optional production data area.
- The drawing area is divided into modules. Columns are numbered 1… left→right and rows lettered A… from the **bottom** up. Put the coordinates outside the border, at least on the left and on the top or bottom. They are optional for schematic design.
- **Note block** (general notes, keynotes, key plan) = the far-right column of the drawing area. The key plan, if any, goes in the lowest module. Signal-flow sheets normally have no key plan.

### Title block fields [NCS UDS 2.3]
Six data blocks, in this top-to-bottom order for the vertical format:
1. **Designer identification**: firm name, address, phone, email/web, logo, **professional seal(s)**, consultants. Seal rules vary by jurisdiction.
2. **Project identification**: project name and address, building/facility, construction phase, project logo, owner/client.
3. **Issue block**: three columns **MARK / DATE / DESCRIPTION**. It records phase issues, addenda, clarifications, and revisions. The **first entry goes at the bottom** and later entries stack upward.
4. **Management block**: preparer's project no., owner contract/project no., CAD file no., phase, **drawn by, checked by**, copyright.
5. **Sheet title block**: what the sheet contains, e.g. "AUDIOVISUAL SIGNAL FLOW DIAGRAM – HUDDLE 01".
6. **Sheet identification block**: sheet ID (`TA601`), optionally with sheet count ("3 OF 12").

Formats: UDS allows a horizontal format (along the bottom) or a vertical format (along the right edge). In both, the sheet ID, sheet title, and management blocks read horizontally. The template uses the **vertical right-side** block [house choice], and its sheet ID sits at the lower right.

Revisions [NCS]: mark each change with a revision cloud plus a delta (triangle) holding the revision number. Log it in the issue block.

### View (drawing block) title [NCS UDS symbol 01 42 00-026]
- Place it **under the drawing, at the lower left**.
- A drawing identifier bubble on the left holds the drawing no. over the sheet ID, e.g. `1 / TA601`.
- The title text is ~1/4 in (6 mm) over an extra-wide underline. The scale line is 3/32 in (2.5 mm) below it. Signal-flow diagrams are **`SCALE: NTS`**, so there is no graphic scale.

### Line weights and types [NCS Plotting Guidelines; NCS FAQ]
- Plotted widths: extra fine 0.13 mm, fine 0.18, thin 0.25, medium 0.35, wide 0.50, extra wide 0.70, then 1.00 / 1.40 / 2.00 mm. They scale down proportionally on half-size prints, so avoid extra fine lines when a half-size plot is likely.
- NCS guidance: visible object lines are typically 0.35 mm and hidden lines 0.25 mm.
- House mapping for AV diagrams [house]:
  - device outlines: 0.50
  - signal lines: 0.35 or 0.50 (see table)
  - control/network lines: 0.25
  - region outlines: 0.18
  - sheet border: 0.70
- SVG unit tip [house]: with 1 user unit = 1/96 in, 0.25 mm = 0.94, 0.35 = 1.32, 0.50 = 1.89, 0.70 = 2.65.

### Text [NCS FAQ on UDS Modules 4 and 7]
- Minimum text height is **3/32 in (2.4 mm)**. Use it for cable labels, port names, notes, and title-block entries.
- House ladder [house, within NCS ranges]:
  - 1/8 in: device tags and note headings
  - 3/16 in: sheet title
  - 1/4 in: view title
  - ≥1/2 in: sheet ID
- Use uppercase sans-serif [house convention].

### Notes, legends, abbreviations [NCS UDS Modules 5 and 7]
- **General notes** are numbered and sit in the note block. Keep terms consistent with the specifications. Avoid vague "SEE SPECIFICATIONS" and cite the section instead.
- **Sheet keynotes** use a **hexagon** indicator with a keynote legend on the same sheet.
- **Abbreviations:** use them sparingly. Don't abbreviate words of five letters or fewer, except in schedule headings. Put the full list on the General sheet (`TA001` or G-series). Each diagram's note block lists only the abbreviations it uses. When in doubt, spell it out.
- A symbol legend and a line-type legend are mandatory on each diagram sheet [house]. If `TA001` exists, keep a short sheet legend and point to `TA001`.

### CAD layer names [NCS AIA CLG]
- Format: `Discipline-Major-Minor-Minor-Status`, where discipline and major are required.
  - Example: `TA-TVVS-SVID`.
  - Status codes: `N` new, `E` existing to remain, `D` existing to demolish, `F` future.
- Prescribed telecom major groups relevant to AV [NCS]:
  - `T□-DIAG` (diagrams), `T□-DIAG-EQPM` (diagrams: equipment)
  - `T□-TVVS` (television and video systems), `T□-SOUN` (sound system), `T□-PROJ` (projector system)
  - `T□-CABL` (cable systems), `T□-DATA` (data/LAN), `T□-CONT` (controls and instrumentation)
- Prescribed signal minor codes under TVVS [NCS]: `SVID` video, `SDGV` digital video, `SRGB` RGB/component, `SAUD` audio, `SDGA` digital audio, `SMIC` microphone, `SCTL` control, `SDAT` data, `SCOM` communications, `SRFI` RF, `SSYN` sync, `SPWR` power.
- Annotation minors [NCS]: `-TEXT`, `-IDEN` (tags), `-NOTE`, `-KEYN`, `-LEGN`, `-SYMB`, `-REVS`. The title block and border go on `G-ANNO-TTLB`.
- Recommended layers for an AV signal-flow sheet [house, built only from prescribed codes]:

| Content | Layer |
|---|---|
| Device boxes | `TA-DIAG-EQPM` |
| Device tags | `TA-DIAG-IDEN` |
| Video lines | `TA-TVVS-SDGV` (baseband/AVoIP digital) / `TA-TVVS-SVID` |
| Analog audio / mic | `TA-TVVS-SAUD` / `TA-TVVS-SMIC` |
| Dante/AES67/AES3 | `TA-TVVS-SDGA` |
| USB | `TA-TVVS-SDAT` |
| Network | `TA-DATA` |
| Control | `TA-TVVS-SCTL` |
| RF | `TA-TVVS-SRFI` |
| Fiber | `TA-CABL-FIBR` |
| Cable IDs | `TA-TVVS-TEXT` |
| Notes / keynotes / legend | `TA-DIAG-NOTE` / `-KEYN` / `-LEGN` |
| Revisions | `TA-DIAG-REVS` |

  User-defined minor codes (4 characters) are allowed but must be documented in the project's NCS compliance statement.

### Color vs. monochrome (conflict resolved)
- NCS sets are normally plotted **black on white**. CAD color assignments drive pen/line width, and sheets are read by **line weight and line type**. That is common practice. NCS V7 adds a "Using colors in symbols" chapter, which was not reviewed here.
- **Decision [house]:**
  - Keep the signal-class colors for screen and PDF review.
  - **Line type + width is the primary code.** Every class is distinguishable when printed B/W or on a monochrome plot.
  - Every line also carries a text label (cable ID + type, or bus name).
  - The legend states that color is supplemental.
  - For a monochrome CAD deliverable, drop the color and keep the line types.

## Signal classes: line type (governs) + color (supplemental)

| Class | Line type (SVG dasharray, 1 unit = 1/96 in) | Plotted width | Screen color |
|---|---|---|---|
| Video: HDMI / DP / SDI (baseband) | continuous | 0.50 mm | `#1d4ed8` |
| Video: HDBaseT / AVoIP | long dash `18 6` | 0.50 mm | `#2563eb` |
| Audio: analog / mic | continuous | 0.35 mm | `#15803d` |
| Audio: Dante / AES67 / AES3 | dash-dot `12 3 2 3` | 0.35 mm | `#0f766e` |
| USB (AV/UC) | dash-dot-dot `12 3 2 3 2 3` | 0.35 mm | `#a16207` |
| Fiber | phantom `24 4 4 4 4 4` | 0.50 mm | `#4d7c0f` |
| RF / antenna | dotted `1 4`, round caps | 0.50 mm | `#be123c` |
| Network / management | long-short `24 4 6 4` | 0.25 mm | `#7c3aed` |
| Control: RS-232 / IR / GPIO / relay / CEC | dashed `6 4` | 0.25 mm | `#c2410c` |

- Device boxes: white fill, black 0.50 mm outline, square corners. The tag is bold at 1/8 in and the description is at 3/32 in.
- Region fills: very light gray (`#f8fafc`) with a 0.18 mm outline.
- Arrowheads are black.

## Layout

```
[ SOURCES ] → [ PROCESS / SWITCH / DSP ] → [ DESTINATIONS ]
[ USB / codec ]
[ CONTROL + NETWORK band ]
```

- Columns, not spaghetti. Keep ≥0.4 in gaps.
- Group by subsystem with a light labeled region.
- The drawing goes in the drawing area left of the note block. The view title goes under it.

## Equipment tags

Pattern: `TYPE-##`, zero-padded and unique project-wide [house]. NCS schedules require a **Mark** column first; the tag is the mark.

| Prefix | Use |
|---|---|
| DISP | Display / projector |
| CAM | Camera |
| MIC | Microphone / array |
| SPK | Loudspeaker / array |
| AMP | Amplifier |
| DSP | Audio DSP |
| MTX / SW | Video matrix / switcher |
| EXT / TX / RX | Extender / encoder / decoder |
| CDC | Codec / room PC / MTR / Zoom appliance |
| CTL | Control processor |
| TP | Touch panel |
| SWI | Network switch |
| PLT | Wall/table plate |
| WAP | Wireless presentation |

If the user already has tags, keep theirs.

## Cable IDs (AVIXA F501.01)

What F501.01 requires [F501, from the public 2015 working draft]:
- Every cable has a **unique, human-readable alphanumeric identifier**, defined by a **labeling scheme stated in the project documentation**.
- The numbering system should use a **consistent number of digits**.
- **F501 deliberately does not prescribe a numbering scheme.** It gives examples of optional prefixes/suffixes: signal type, cable type, room/floor/building, location, core.
- Optional secondary elements: source→destination identifier, user-accessible identifier (within 3 in of the connector), barcode.
- Physical labels:
  - machine-printed, all caps, sans-serif
  - primary text ≥2.5 mm (3/32 in), secondary ≥2.1 mm
  - high contrast, durable for the life of the cable
  - placed 1–12 in (25–300 mm) from the connector at **each end**, reading along the cable axis
- Power cabling furnished as part of the AV system is labeled too.

Default scheme [house, F501-conformant]:
- Primary ID: `C-###` (3 digits), **unique across the whole project**. When a project spans rooms, add a room prefix so IDs stay unique: `HD01-C-014`.
- Drawing label mid-span: `C-014  HDMI  OUT1→IN2`. That is the ID plus type and ports. The secondary source→destination text belongs on the cable schedule and the physical label, e.g. `DSP-01 OUT3 / SPK-01 IN`.
- State the scheme in a general note. Every ID on the drawing must appear in the cable schedule.
- If the user or owner has a scheme, such as origin-destination-number, use theirs. It is F501-conformant as long as IDs are unique and consistently formatted.

## AVIXA D401.01: documentation types and where these sheets fit

D401.01 classifies projects as **simple / moderate / complex** using a points matrix. The factors are sites, budget, rooms, trades, stakeholders, risk, schedule, and so on. Each class sets minimum documentation [D401, from the public 2022 technical-review draft; the final 2023 text may differ]:

- **All projects:**
  - Responsibility Assignment Matrix (RACI) and project file record
  - Scope of work, BOM
  - **Architectural locational information**: device locations using **J-STD-710 symbols**, mounting heights, back boxes
  - Architectural references/details
  - **System interconnection information**: how every component connects, with part numbers, cable type, **cable labels**, and network detail. The TA6xx signal-flow/wiring sheet delivers this.
  - Equipment mounting information (racks, per AVIXA F502 rack standards)
  - Performance verification (ANSI/AVIXA D402.02, formerly INFOCOMM 10)
  - As-builts, closeout list
- **Moderate adds:**
  - **Detailed project information**: cover page, drawing index, responsibility schedule, **symbol key, abbreviations, general notes**. This maps to NCS `TA001`/G-sheets.
  - Individual device details (plates, pinouts, panels), referenced from other drawings
  - Cable pathway information
- **Complex adds:** project schedule, architectural sections, display information (viewing distances and angles per AVIXA V202.01), audio coverage information (per AVIXA A102.01).

Practical consequences for this skill:
- A functional diagram alone does **not** satisfy "system interconnection information". Deliver a wiring sheet with cable IDs, cable types, and ports when the user needs D401-level documentation.
- Tags and cable IDs must be traceable across the BOM, drawings, and schedules. As-builts update the same sheets.

## Symbols

- **J-STD-710** (ANSI/CTA/CEDIA/AVIXA, 2015, free from AVIXA) covers **floor-plan and reflected-ceiling-plan symbols** for AV and control devices. D401.01 points to it for locational drawings. Use it on TA1xx plans, not on signal-flow sheets.
- The NCS UDS Symbols module (Division 27 Communications) also has AV/communications symbols; V7 added 43 new Division 27 symbols.
- **No AVIXA or NCS standard defines signal-flow block symbols.** Tagged rectangles, arrows, off-sheet connectors, and line types are industry practice [house]. The sheet's symbol legend defines them.
- Reference symbols that **are** NCS: drawing identifier bubble, hexagon keynote, revision delta + cloud, match line, north arrow.

## Ports

- Label the port the cable actually lands on (`HDMI OUT 1`, `Dante Primary`, `USB-B Host`, `PoE`), at the line end inside the box.
- Do not invent port maps for a model you have not been given. Use generic `IN`/`OUT` and TBD.

## What must appear on a wiring sheet

- Every active device in that room's BOM
- Extenders, USB hubs, DSPs, and the room switch if it carries AV or powers AV devices over PoE
- Codec USB routing (camera, mics, speakerphone)
- Wireless mic receivers and antenna distribution, if in scope
- Notes for HDCP, EDID management, analog vs Dante tap points, mix-minus, far-end audio
- An F501 cable ID on every line, matching the cable schedule

## Functional sheet differences

- Use named buses (`Program Video`, `Content Audio`, `Far-End`, `Dante: Room`) instead of cable IDs.
- Still tag every box. Still include a legend, NCS title block, sheet ID, and view title with `SCALE: NTS`.

## Sources (checked 2026-09-26)

- NCS V7 release info: https://www.nationalcadstandard.org/ncs7/new.php · FAQ (line widths, text heights, keynote hexagon, revision delta, `G-ANNO-TTLB`): https://nationalcadstandard.org/ncs7/faqs.php
- UDS Module 1 sheet ID excerpt (TA = Audio Visual; sheet types): https://www.nationalcadstandard.org/ncs6/pdfs/ncs6_uds1.pdf (V5 edition: .../ncs5/pdfs/ncs5_uds1.pdf)
- UDS Module 2 sheet sizes, layout, title block blocks (third-party copy of the UDS text): https://pdfcoffee.com/uds-sheet-organization-pdf-free.html
- UDS Module 6 symbols excerpt (drawing block title, revision indicator): https://www.nationalcadstandard.org/ncs6/pdfs/ncs6_uds6.pdf
- Plotting Guidelines line-width table: https://www.nationalcadstandard.org/ncs6/pdfs/ncs6_pg.pdf
- AIA CLG layer name format: https://www.nationalcadstandard.org/ncs6/pdfs/ncs6_clg_lnf.pdf · full V5 CLG layer lists (telecom/TVVS): https://facilities.duke.edu/sites/default/files/AIA%20CAD%20Layer%20Guidelines.pdf
- D401.01 listing: https://www.avixa.org/resources/standards/documentation-requirements-for-audiovisual-systems · tech-review draft: https://cdn.avixa.org/production/docs/default-source/default-document-library/d401.01_tech_review.pdf
- F501.01 listing: https://www.avixa.org/resources/standards/cable-labeling-for-av-systems · 2015 working draft text: https://pdfcoffee.com/download/cable-labeling-working-draft-for-town-hall-pdf-free.html
- J-STD-710: https://www.avixa.org/resources/standards/av-control-architectural-drawing-symbols
