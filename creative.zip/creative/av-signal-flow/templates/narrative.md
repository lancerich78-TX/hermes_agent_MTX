# [Project] — [Room] AV System Narrative

**Revision:** A  |  **Date:** YYYY-MM-DD  |  **By:**

## 1. Purpose and design intent

[What the room is for. Who uses it. Success looks like: local presentation, UC, program playback, assistive listening, overflow, etc.]

## 2. User scenarios

1. **Walk-in / occupancy:** …
2. **Local presentation (BYOD):** …
3. **Video conference:** …
4. **[Other: record, overflow, worship, production]** …

## 3. Video

Sources: [PLT-01 HDMI, WAP-01, CDC-01].
Routing: [MTX-01 / TX-RX / AVoIP].
Displays: [DISP-01 primary, DISP-02 confidence].
Notes: [resolution, HDCP, EDID, mirroring vs independent].

## 4. Audio

Capture: [MIC-01 …] → [DSP-01].
Program: [content de-embed / analog / Dante] → DSP.
Reinforcement: DSP → [AMP-01] → [SPK-01 …] zones.
Conferencing: AEC reference, far-end to speakers, mics to codec USB/Dante.
Notes: [mix-minus, privacy mute, paging ducking].

## 5. Conferencing, record, stream

[CDC-01 platform, camera tracking, content vs camera switching, recording endpoint.]

## 6. Control sequence of operations

| Trigger | System response |
|---|---|
| Occupancy / schedule | … |
| Touch panel “Presentation” | … |
| Touch panel “Conference” | … |
| Hang up / vacancy | … |

## 7. Network and power assumptions

VLANs, PoE budget, Dante/AVoIP multicast, who furnishes the switch, UPS.

## 8. Infrastructure, furnished-by, exclusions

Racks, plates, conduit, OFE displays, owner-furnished codec, acoustics, lighting control interface — state in/out of scope.

## Equipment list (tags)

| Tag | Make / Model | Location | Role |
|---|---|---|---|
| | | | |

## Assumptions and TBD

- 
