---
name: av-signal-flow
description: "Use this when drawing AV (audiovisual) signal flow, functional/block, wiring, or riser diagrams, or writing AV system narratives, design intent, or sequences of operation."
version: 0.1.0
author: Lance Richards (Electra Link), CTS-D
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [av, audiovisual, signal-flow, diagrams, narratives, AVIXA]
    related_skills: [architecture-diagram, docx, pdf, av-bill-of-materials, av-scope-of-work]
---

# AV Signal Flow & Narratives

Produce construction-document quality **signal-flow / functional diagrams** and **system narratives** for professional audiovisual projects. Do not use the dark cloud `architecture-diagram` look. These are trade drawings and written design intent, not infographics.

Supporting files live beside this skill (paths are relative to the skill folder):
- `references/conventions.md`: read before drawing. It covers AIA/NCS sheet rules, AVIXA D401.01/F501.01/J-STD-710, drawing types, tags, cable IDs, line types, and ports.
- `templates/signal-flow.html`: copy its structure for the diagram. It is an NCS-style ARCH D sheet with a right-side title block, note block, and view title.
- `templates/narrative.md` — copy its structure for the narrative.

## When to Use

- Signal flow, functional, one-line, wiring, or block diagrams for AV systems
- System narratives, design intent, sequences of operation, room descriptions
- Conference rooms, classrooms, HOW, theaters, boardrooms, digital signage, production/broadcast, command/NOC
- Reviewing or redrawing a user's BOM, sketch, or existing drawing

Typical rooms: corporate huddle/meeting/boardroom, classrooms/lecture halls, plus building-wide risers covering multiple room types.

Default deliverable: **functional / block diagram** (named buses, not every patch) plus a matching narrative when the user also wants writing. Promote to a cable-accurate wiring sheet only when they ask for IDs, ports, or a cable schedule. Produce a riser when the scope is vertical/backbone or campus, not a single room.

## Inputs to collect (don't invent SKUs)

If the user did not give them, ask only what changes the drawing:

1. Room type and use cases (present, UC, program, record, overflow)
2. Device list or BOM (make/model or functional placeholders)
3. Drawing type: default **functional** (subsystems / named buses). Use **wiring/signal flow** only if they want every cable, or **riser** for building vertical.
4. House/architect standards: sheet size and title block (default ARCH D, NCS layout), sheet numbering (default `TA6xx`), cable labeling scheme (default F501-conformant `C-###`), OFE vs furnished

If they gave a BOM or sketch, start drawing. Mark unknown models as `TBD`; never pick brands to fill gaps unless asked.

## Procedure

1. **Inventory first.** Table every active device: tag (`DISP-01`, `DSP-01`, `MIC-01`), make/model, location (table/wall/ceiling/rack), signals in/out. Tags must match the narrative and any BOM.
2. **Split subsystems.** Video sources, video distribution, displays; audio capture, DSP/mix, amplification, loudspeakers; conferencing/USB; control; network/AVoIP. One sheet per room unless the user wants a building riser.
3. **Lay out left to right.** Sources left, processing/switching/DSP center, sinks right. Control and network as a lower band or dashed overlay, never mixed into video so they look like HDMI. Completion: no overlapping boxes, no arrows through boxes.
4. **Draw buses, not spaghetti.** On a functional sheet, connect subsystems with named buses (`Program Video`, `Content Audio`, `Far-End`, `Dante: Room`). Show format conversion as a labeled hop. Bidirectional Dante/AES67/USB as double-arrow or two labels. Cable IDs and port-to-port lines belong on a wiring sheet only.
5. **Write the narrative from the same inventory.** Same tags, same rooms, same signal paths. No device on the drawing that the narrative ignores, and vice versa.
6. **Deliver.** Default: a print-ready HTML diagram written to a file (`write_file`), then render it to PNG at sheet size (headless Chromium/Chrome/Edge, `--window-size=3456,2304` for ARCH D at 96 dpi) to check it visually, and show it with `::preview{file="..."}` on its own line. Write or patch a narrative only when the user asks for writing. If they have said diagrams-only, do not touch `.md` narratives. Export `.docx`/`.pdf` only if asked (`docx` / `pdf` skills). Mermaid is a scratch draft only; promote to HTML before calling it a drawing.

## Diagram rules

Standards basis: AIA/NCS (UDS sheet organization, CLG layers, Plotting Guidelines) and AVIXA (D401.01 documentation, F501.01 cable labels). Details and sources are in `conventions.md`. House or architect standards win.

- **Sheet (NCS):**
  - White page, ARCH D 36×24 landscape (or ANSI D, or whatever the architect uses), with `@page` print CSS.
  - UDS margins, with drawing-area coordinates in the margin.
  - Right-side title block with the six UDS blocks: designer (with seal area), project, issue (MARK/DATE/DESCRIPTION, first entry at the bottom), management (project no., drawn/checked by, issue date), sheet title, and sheet ID.
- **Sheet ID:**
  - `TA` + type + sequence: `TA601` for diagrams, `TA001` for legend/general.
  - No hyphen after `TA`. Don't use `AV-…` unless the project standard does.
- **View title:** under the drawing, lower left. Bubble `1 / TA601`, title at ~1/4 in, then `SCALE: NTS`.
- **Note block:** the far-right column of the drawing area. It holds numbered general notes, hexagon keynotes, the line-type and symbol legend, and the abbreviations used on the sheet. The legend never sits over devices.
- **Device box:** tag (bold, 1/8 in), function, make/model, and the ports at the line ends. The equipment tag is the primary label.
- **Signal class:** coded by **line type + width first, color second**, so the sheet survives B/W plotting. Every line also carries a text label (cable ID/type or bus name).
- **Line widths:** use NCS widths only (0.25 / 0.35 / 0.50 / 0.70 mm). Minimum text is 3/32 in.
- **Cable IDs (F501.01):** unique project-wide, consistent digits, and matching the cable schedule. State the scheme in a general note.
- **Z-order:** cables behind boxes. Keep crossings to a minimum.
- **Revisions:** mark changes with a cloud and a delta, and log them in the issue block.
- Do not put room geometry, furniture, or ceiling grids on a signal-flow sheet.
- Do not omit USB, control, Dante, or the LAN switch because they "aren't AV."
- Power/PoE: note PoE on the device or a note block; don't clutter the sheet with every IEC cord unless the ask is a power riser.

## Narrative rules

Audience is typically owner, architect, GC, and integrator: precise, not salesy.

Required sections (drop any that don't apply, don't pad):

1. Project / room purpose and design intent
2. User scenarios (what happens when someone walks in / shares / joins a call)
3. Video signal path
4. Audio signal path (including AEC, mix-minus, zones, paging if any)
5. Conferencing / recording / streaming
6. Control and automation (SOO: inputs to outputs, occupancy, presets)
7. Network / VLANs / AVoIP / PoE assumptions
8. Infrastructure (racks, plates, conduit, OFCI/CFCI, exclusions)

Name equipment by **tag + function**. Put make/model in an equipment list, not every sentence. Flag assumptions and TBDs in a short list at the end.

Control intent vs SOO: intent is goals and strategies; SOO is button/preset/occupancy mapped to concrete device behavior. Don't mix them into one mushy paragraph.

## Pitfalls

- Cloud-architecture aesthetic, hero cards, or decorative icons.
- Boxes with no tag, or cables with no ID/type/ports.
- Functional diagram labeled as a wiring diagram (or the reverse).
- Invented part numbers, DSP channel counts, or switcher I/O that the BOM doesn't support.
- One-way arrows on Dante, USB, or talkback paths.
- HDCP/EDID/USB 2.0 vs 3.0 traps left unstated when they affect the design.
- Narrative that describes a different system than the drawing.

## Verification

Before delivering:

- [ ] Every BOM/active device has a tag and appears once on the correct sheet
- [ ] Every line has cable ID + signal type + ports (wiring) or a named bus (functional)
- [ ] Format converters and extenders are shown, not implied
- [ ] Legend matches the line types, widths, and colors actually used. Signal classes are still distinguishable in grayscale.
- [ ] Wiring sheet (D401 "system interconnection information"): every cable has a unique F501-style ID, a type, and ports, and matches the cable schedule
- [ ] NCS sheet: sheet ID `TA6xx` (no hyphen) matches the title block, file name, and view-title bubble. All six title-block blocks are filled or marked TBD. Issue block entries stack from the bottom. View title reads `SCALE: NTS`.
- [ ] Text ≥ 3/32 in at plotted size; only NCS line widths used
- [ ] Abbreviations used on the sheet are listed (or referenced to `TA001`); keynotes use hexagons
- [ ] Narrative uses the same tags; SOO covers each user scenario named in intent
- [ ] Assumptions/TBD/exclusions listed
- [ ] HTML opens, and print-to-PDF gives one page at the sheet size (e.g. 2592×1728 pt for ARCH D). A full-size PNG render has no overlapping text/boxes and no arrows through boxes.

## Output paths

Save under the project folder if the user has one, else the current working directory:

```
./<project>-<room>-TA601-signal-flow.html
./<project>-<room>-narrative.md
```
