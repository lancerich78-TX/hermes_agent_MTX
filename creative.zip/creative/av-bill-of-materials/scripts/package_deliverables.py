#!/usr/bin/env python3
"""Package AV design deliverables: one folder per branded solution with
Drawings (PDF), BoM (xlsx) and Scope of Work (docx), a README.txt, and a zip.

Usage:
    python package_deliverables.py package.json [-o OUTPUT_DIR]

package.json (see templates/package_input.example.json):
{
  "package_name": "AV-Design-Package-2026-01-01",
  "title": "Electra Link, Inc. - Conference Rooms 101 and 102",
  "prepared_by": "Designer Name, AV Designer",
  "notes": ["Latest revisions only."],
  "solutions": [
    {"folder": "Crestron", "doc_set": "AV-CCC-2026-V1", "description": "Crestron option",
     "drawings": ["path/to/combined.pdf", "path/to/room101.pdf"],
     "bom": "path/to/AV-CCC-2026-V1-BoM.xlsx",
     "sow": ["path/to/AV-CCC-2026-V1-Scope-of-Work.docx"]}
  ]
}
Relative paths are resolved against the JSON file's folder. Only the listed files are
packaged (put latest revisions only in the manifest). Existing output is replaced.
"""
import argparse
import json
import os
import shutil
import sys
import zipfile

SUBFOLDERS = [('drawings', 'Drawings', 'Drawings (PDF)'),
              ('bom', 'BoM', 'Bill of Materials (Excel)'),
              ('sow', 'Scope of Work', 'Scope of Work (editable Word)')]


def as_list(v):
    return [] if v is None else (v if isinstance(v, list) else [v])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('manifest')
    ap.add_argument('-o', '--output-dir', default=None, help='default: folder of the manifest')
    a = ap.parse_args()
    base = os.path.dirname(os.path.abspath(a.manifest))
    with open(a.manifest, encoding='utf-8') as fh:
        m = json.load(fh)
    out_dir = os.path.abspath(a.output_dir or base)
    root = os.path.join(out_dir, m['package_name'])
    if os.path.isdir(root):
        shutil.rmtree(root)
    os.makedirs(root)
    readme = [m.get('heading') or m['package_name'].upper(), m.get('title', ''),
              f"Prepared by: {m.get('prepared_by', 'TBD')}",
              f"{len(m['solutions'])} branded design option(s). Each folder holds "
              "Drawings (PDF), Bill of Materials (Excel) and Scope of Work (editable Word)."]
    readme += m.get('notes', [])
    missing = []
    for sol in m['solutions']:
        readme += ['', f"{sol['folder']}/  (document set {sol.get('doc_set', 'TBD')}"
                   + (f", {sol['description']}" if sol.get('description') else '') + ')']
        for key, sub, _label in SUBFOLDERS:
            files = as_list(sol.get(key))
            if not files:
                missing.append(f"{sol['folder']}: no {sub} file listed")
                continue
            os.makedirs(os.path.join(root, sol['folder'], sub), exist_ok=True)
            for src in files:
                p = src if os.path.isabs(src) else os.path.join(base, src)
                if not os.path.isfile(p):
                    missing.append(f"{sol['folder']}: missing {p}")
                    continue
                name = os.path.basename(p)
                shutil.copy2(p, os.path.join(root, sol['folder'], sub, name))
                readme.append(f"  {sub}/{name}")
    readme += ['', 'BoM conventions: unit price left blank for pricing; Extended is a formula;',
               'yellow rows = TBD / confirm before order; blue = owner-furnished (OFE). Sources on the Summary tab.',
               'Open items are listed on each drawing and at the end of each Scope of Work.']
    with open(os.path.join(root, 'README.txt'), 'w', encoding='utf-8', newline='\r\n') as fh:
        fh.write('\n'.join(readme) + '\n')
    zpath = root + '.zip'
    if os.path.exists(zpath):
        os.remove(zpath)
    with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as z:
        for dp, _dn, fns in os.walk(root):
            for fn in sorted(fns):
                full = os.path.join(dp, fn)
                z.write(full, os.path.relpath(full, root))
    print(f"Wrote {root}\nWrote {zpath}")
    for x in missing:
        print('WARNING', x, file=sys.stderr)
    return 1 if missing else 0


if __name__ == '__main__':
    sys.exit(main())
