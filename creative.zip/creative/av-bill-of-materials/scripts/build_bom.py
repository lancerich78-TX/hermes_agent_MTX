#!/usr/bin/env python3
"""Build an Electra Link-branded AV Bill of Materials (.xlsx) from a JSON project file.

Usage:
    python build_bom.py project_bom.json [-o OUTPUT.xlsx] [--logo LOGO.png]

All project data lives in the JSON input (see templates/bom_input.example.json).
Requires: openpyxl (pip install openpyxl). Pillow is optional (keeps the logo aspect ratio).

Workbook layout:
  - "Summary" tab: one row per room (system, source drawing, line-item count, TBD count,
    subtotal formula), grand total, color legend, basis of BoM, manufacturer sources list.
  - One tab per room: branded header, frozen column-header row, autofilter, optional
    section rows (Equipment / Licensing / Cable & Infrastructure), subtotal, notes.
  - Unit Price is left blank for pricing; Extended is a formula
    (Qty x Unit Price; for "Lot"/"TBD" quantities Extended = Unit Price).
  - Yellow rows = TBD / confirm before order; blue rows = owner-furnished (OFE).
"""
import argparse
import json
import os
import sys

from openpyxl import Workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.page import PageMargins

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_LOGO = os.path.join(HERE, '..', 'assets', 'electra-link-logo.png')

# ---- Brand / style config -------------------------------------------------
RED, DARK, GREY = 'E8474C', '1F2937', 'F3F4F6'
TBD_FILL, OWN_FILL = 'FFF2CC', 'E7EEF7'           # yellow = TBD, blue = owner-furnished
SECTION_FILL = 'E5E7EB'
MONEY = '"$"#,##0.00;[Red]-"$"#,##0.00;"-"'
THIN = Side(style='thin', color='BFBFBF')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
FONT = 'Arial'

# (header, width, json key or None)
COLUMNS = [
    ('Item', 6, None),
    ('Tag', 16, 'tag'),
    ('Qty', 7, 'qty'),
    ('Manufacturer', 14, 'mfr'),
    ('Model / Part No.', 26, 'model'),
    ('Description', 44, 'desc'),
    ('Furnished By', 14, 'furnished'),
    ("What's in the Box", 40, 'in_box'),
    ('Notes / Source', 56, 'notes'),
    ('Unit Price', 12, None),
    ('Extended', 14, None),
]
NCOL = len(COLUMNS)
COL = {h: i + 1 for i, (h, _, _) in enumerate(COLUMNS)}
L = {h: get_column_letter(i) for h, i in COL.items()}

DEFAULT_ROOM_NOTES = [
    'Qty "Lot" = quantity/length TBD; functional (block) diagrams give no cable lengths. Extended for Lot/TBD rows = Unit Price.',
    'Items marked "Included with ..." ship with the parent device (manufacturer in-box list): included, no separate cost.',
    'Owner-furnished (OFE) rows are listed for completeness and coordination; not priced by contractor.',
    'Part numbers, material numbers and box contents verified on manufacturer websites; see the Summary tab for sources. Unverifiable items are marked TBD.',
]


def f(size=9, bold=False, color='000000', italic=False):
    return Font(name=FONT, size=size, bold=bold, color=color, italic=italic)


def fill(color):
    return PatternFill('solid', fgColor=color)


def is_owner(item):
    return str(item.get('furnished', '')).lower().startswith('owner')


def is_tbd(item):
    if 'tbd' in item:
        return bool(item['tbd'])
    return any('TBD' in str(item.get(k, '')) for k in ('model', 'qty', 'mfr'))


def add_logo(ws, logo, height=62):
    if not logo or not os.path.exists(logo):
        return
    img = XLImage(logo)
    try:
        from PIL import Image as PILImage
        with PILImage.open(logo) as im:
            ratio = im.width / im.height
    except Exception:
        ratio = img.width / img.height if img.height else 2.2
    img.height = height
    img.width = int(height * ratio)
    ws.add_image(img, 'A1')


def header_block(ws, cfg, title, subtitle, ncols, sc, logo):
    p, co = cfg['project'], cfg.get('company', {})
    ws.row_dimensions[1].height = 30
    ws.row_dimensions[2].height = 18
    ws.row_dimensions[3].height = 18
    add_logo(ws, logo)
    lines = [
        (f"{co.get('short_name', 'ELECTRA LINK, INC.')}  |  {p['doc_set']}  |  {title}", f(14, True, DARK)),
        (subtitle, f(9, color='555555')),
        ('  |  '.join([
            f"Owner: {p.get('owner', 'TBD')}", f"Address: {p.get('address', 'TBD')}",
            f"Project No.: {p.get('project_no', 'TBD')}", f"Prepared by: {p.get('prepared_by', 'TBD')}",
            f"Date: {p.get('date', 'TBD')}", f"Pricing: to be completed by {co.get('name', 'Electra Link, Inc.')}",
        ]), f(9, color='555555')),
    ]
    for r, (text, font) in enumerate(lines, 1):
        ws.merge_cells(start_row=r, start_column=sc, end_row=r, end_column=ncols)
        ws.cell(r, sc, text).font = font
    for c in range(1, ncols + 1):
        ws.cell(4, c).fill = fill(RED)
    ws.row_dimensions[4].height = 4


def room_sheet(wb, cfg, room, logo, warnings):
    name = room['name']
    ws = wb.create_sheet(room.get('tab', name)[:31])
    header_block(ws, cfg, f"BILL OF MATERIALS - {room.get('title', 'ROOM ' + name).upper()}",
                 f"Source drawing: {room.get('drawing', 'TBD')}  |  Unit Price / Extended left blank for pricing  |  "
                 f"Yellow = TBD / confirm  |  Blue = owner-furnished", NCOL, 3, logo)
    hr = 6
    for i, (h, w, _) in enumerate(COLUMNS, 1):
        c = ws.cell(hr, i, h)
        c.font = f(10, True, 'FFFFFF')
        c.fill = fill(DARK)
        c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        c.border = BORDER
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[hr].height = 22

    r, n, tbd_count = hr + 1, 0, 0
    current_section = None
    for item in room['items']:
        sec = item.get('section')
        if sec and sec != current_section:
            current_section = sec
            ws.cell(r, COL['Tag'], sec.upper()).font = f(9.5, True, DARK)
            for i in range(1, NCOL + 1):
                ws.cell(r, i).fill = fill(SECTION_FILL)
                ws.cell(r, i).border = BORDER
            r += 1
        n += 1
        tbd, own = is_tbd(item), is_owner(item)
        tbd_count += tbd
        notes = item.get('notes', '')
        if item.get('source'):
            notes = (notes + ' ' if notes else '') + f"Source: {item['source']}"
        if not item.get('source') and not own and not tbd and 'Included with' not in str(item.get('model', '')) \
                and str(item.get('mfr', '')).upper() not in ('TBD', 'CONTRACTOR', 'OWNER'):
            warnings.append(f"[{name}] line {n} {item.get('model')}: no manufacturer source cited")
        for i, (h, _, key) in enumerate(COLUMNS, 1):
            v = n if h == 'Item' else (notes if key == 'notes' else (item.get(key, '') if key else None))
            c = ws.cell(r, i, v)
            c.font = f(9)
            c.border = BORDER
            c.alignment = Alignment(vertical='top', wrap_text=True,
                                    horizontal='center' if h in ('Item', 'Qty', 'Furnished By') else 'left')
        qc, pc = f"{L['Qty']}{r}", f"{L['Unit Price']}{r}"
        ws.cell(r, COL['Unit Price']).number_format = MONEY
        e = ws.cell(r, COL['Extended'], f'=IF({pc}="","",IF(ISNUMBER({qc}),{qc}*{pc},{pc}))')
        e.number_format = MONEY
        e.alignment = Alignment(vertical='top', horizontal='right')
        row_fill = TBD_FILL if tbd else (OWN_FILL if own else ('FFFFFF' if n % 2 else 'FAFAFA'))
        for i in range(1, NCOL + 1):
            ws.cell(r, i).fill = fill(row_fill)
        if own:
            ws.cell(r, COL['Furnished By']).fill = fill(OWN_FILL)
            ws.cell(r, COL['Furnished By']).font = f(9, True, '1F4E79')
        if tbd:
            for h in ('Model / Part No.', 'Notes / Source'):
                if 'TBD' in str(ws.cell(r, COL[h]).value):
                    ws.cell(r, COL[h]).font = f(9, h == 'Model / Part No.', '9C5700')
        r += 1
    first, last = hr + 1, r - 1
    ws.cell(r, COL['Notes / Source'], 'ROOM SUBTOTAL (contractor-furnished, excl. tax)').font = f(10, True)
    ws.cell(r, COL['Notes / Source']).alignment = Alignment(horizontal='right')
    st = ws.cell(r, COL['Extended'], f"=SUM({L['Extended']}{first}:{L['Extended']}{last})")
    st.number_format, st.font = MONEY, f(10, True)
    for i in range(1, NCOL + 1):
        ws.cell(r, i).border = Border(top=Side(style='medium', color=DARK))
        ws.cell(r, i).fill = fill(GREY)
    subtotal_row = r
    r += 2
    notes = room.get('notes') or cfg.get('room_notes') or DEFAULT_ROOM_NOTES
    for j, t in enumerate(['Notes:'] + [f'{k}. {x}' for k, x in enumerate(notes, 1)]):
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NCOL)
        ws.cell(r, 1, t).font = f(8.5, j == 0, '444444', italic=j > 0)
        r += 1
    ws.freeze_panes = ws.cell(hr + 1, 1)
    ws.auto_filter.ref = f"A{hr}:{get_column_letter(NCOL)}{last}"
    ws.print_title_rows = f'{hr}:{hr}'
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.paperSize = ws.PAPERSIZE_LETTER
    ws.page_setup.fitToWidth, ws.page_setup.fitToHeight = 1, 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins = PageMargins(left=0.3, right=0.3, top=0.4, bottom=0.5)
    ws.oddFooter.left.text = f"{cfg.get('company', {}).get('name', 'Electra Link, Inc.')} - {cfg['project']['doc_set']} BoM"
    ws.oddFooter.right.text = 'Page &P of &N'
    ws.sheet_view.zoomScale = 90
    return {'ws': ws, 'first': first, 'last': last, 'subtotal_row': subtotal_row, 'tbd': tbd_count, 'lines': n}


def summary_sheet(wb, cfg, rooms_info, logo):
    s = wb.active
    s.title = 'Summary'
    header_block(s, cfg, 'BoM SUMMARY', cfg['project'].get('system_summary', ''), 6, 2, logo)
    for col, w in zip('ABCDEF', [22, 62, 22, 12, 12, 16]):
        s.column_dimensions[col].width = w
    for i, h in enumerate(['Room', 'System', 'Source Drawing', 'Line Items', 'TBD Lines', 'Subtotal'], 1):
        c = s.cell(6, i, h)
        c.font, c.fill, c.border = f(10, True, 'FFFFFF'), fill(DARK), BORDER
        c.alignment = Alignment(horizontal='center', vertical='center')
    r = 7
    for room, info in rooms_info:
        tab = info['ws'].title
        vals = [room['name'], room.get('system', ''), room.get('drawing', 'TBD'),
                f"=COUNT('{tab}'!A{info['first']}:A{info['last']})", info['tbd'],
                f"='{tab}'!{L['Extended']}{info['subtotal_row']}"]
        for i, v in enumerate(vals, 1):
            c = s.cell(r, i, v)
            c.font, c.border = f(9.5), BORDER
            c.alignment = Alignment(vertical='top', wrap_text=True, horizontal='center' if i in (1, 4, 5) else 'left')
        s.cell(r, 6).number_format = MONEY
        s.row_dimensions[r].height = 30
        r += 1
    s.cell(r, 5, 'TOTAL').font = f(10, True)
    t = s.cell(r, 6, f'=SUM(F7:F{r - 1})')
    t.number_format, t.font = MONEY, f(10, True)
    for i in range(1, 7):
        s.cell(r, i).fill = fill(GREY)
        s.cell(r, i).border = Border(top=Side(style='medium', color=DARK))
    r += 2
    for text, color in [('Legend', None), ('TBD / confirm before order', TBD_FILL), ('Owner-furnished (OFE) - not priced', OWN_FILL)]:
        s.cell(r, 1, text).font = f(9.5, color is None)
        if color:
            s.cell(r, 1).fill = fill(color)
            s.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
        r += 1
    r += 1
    basis = cfg.get('basis', []) + [
        'Unit Price / Extended intentionally blank (no prices invented). Extended = Qty x Unit Price (Lot/TBD rows: = Unit Price).']
    sources_title = f"Manufacturer sources checked {cfg['project'].get('sources_checked', cfg['project'].get('date', ''))}".strip()
    block = [('Basis of BoM', True)] + [('- ' + b, False) for b in basis] + [('', False), (sources_title, True)] + \
            [('- ' + x, False) for x in cfg.get('sources', ['TBD - no sources listed'])]
    for text, bold in block:
        s.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
        c = s.cell(r, 1, text)
        c.font = f(9, bold)
        c.alignment = Alignment(wrap_text=True, vertical='top')
        if len(text) > 140:
            s.row_dimensions[r].height = 13 * (len(text) // 140 + 1)
        r += 1
    s.freeze_panes = 'A7'
    s.page_setup.orientation = 'landscape'
    s.page_setup.fitToWidth, s.page_setup.fitToHeight = 1, 0
    s.sheet_properties.pageSetUpPr.fitToPage = True


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('input', help='project BoM JSON file')
    ap.add_argument('-o', '--output', help='output .xlsx (default: <doc_set>-BoM.xlsx next to the input)')
    ap.add_argument('--logo', help='logo PNG (default: ../assets/electra-link-logo.png)')
    a = ap.parse_args()
    with open(a.input, encoding='utf-8') as fh:
        cfg = json.load(fh)
    out = a.output or cfg.get('output') or os.path.join(os.path.dirname(os.path.abspath(a.input)),
                                                        f"{cfg['project']['doc_set']}-BoM.xlsx")
    logo = a.logo or cfg.get('logo') or DEFAULT_LOGO
    wb = Workbook()
    warnings, infos = [], []
    for room in cfg['rooms']:
        infos.append((room, room_sheet(wb, cfg, room, logo, warnings)))
    summary_sheet(wb, cfg, infos, logo)
    wb.save(out)
    print(f"Wrote {out}")
    for room, info in infos:
        print(f"  {room['name']}: {info['lines']} lines, {info['tbd']} TBD")
    for w in warnings:
        print('WARNING', w, file=sys.stderr)


if __name__ == '__main__':
    main()
