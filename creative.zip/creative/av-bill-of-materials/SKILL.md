---
name: av-bill-of-materials
description: "Use this when building or updating an Electra Link-branded AV Bill of Materials (Excel) from AV drawings: Summary plus per-room tabs, verified part numbers and in-box contents with sources, blank pricing, TBD/owner-furnished color coding, licensing lines, and design-package zips."
version: 0.1.0
author: Lance Richards (Electra Link), CTS-D
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [av, audiovisual, bom, bill-of-materials, excel, xlsx, electra-link, estimating]
    related_skills: [av-signal-flow, av-scope-of-work]
---

# AV Bill of Materials (Electra Link)

Build an Electra Link-branded Excel Bill of Materials from AV drawings (signal-flow / functional sheets, riser, BOM markups). Output is a pricing-ready workbook: every part verified on the manufacturer's site, prices left blank for estimating, TBDs flagged instead of guessed.

Supporting files live beside this skill (paths are relative to the skill folder):
- `scripts/build_bom.py`: generator. All project data comes from a JSON input file; nothing project-specific lives in the script. Brand colors, columns and default notes are in the config block at the top.
- `templates/bom_input.example.json`: input template (company, project, basis, sources, rooms > items).
- `scripts/package_deliverables.py` + `templates/package_input.example.json`: builds the per-solution deliverable folders, README and zip.
- `assets/electra-link-logo.png`: logo placed on every tab.

Related skills: `av-signal-flow` (the drawings this BoM is taken from; same tags) and `av-scope-of-work` (the SOW built from the same inventory).

## When to Use

- The user wants a BoM, equipment list or parts list from AV drawings, a sketch or a device list
- Updating a BoM after a drawing revision
- Preparing a pricing-ready workbook for Electra Link estimating, or a multi-brand design package (for example a Crestron option and a Q-SYS option)

## Rules (non-negotiable)

1. **Verify every part number, material number and in-box list on the manufacturer's website** (product page, spec sheet, user manual "in the box" section, licensing page). Record each source in the item's `source` field and in the `sources` list (Summary tab), with the date checked.
2. **Unverifiable = TBD.** If a part number, finish/order code or box content can't be confirmed, keep the best-known model name, add "TBD" and set `"tbd": true`. The row turns yellow and goes on the SOW open-items list. Never invent a SKU.
3. **Never invent pricing.** Unit Price stays blank. Extended is a formula: Qty x Unit Price, or = Unit Price for Lot/TBD quantities.
4. **Included cables and accessories** (per the manufacturer's in-box list) get their own row with model "Included with <parent>" and the note "Included, no separate cost."
5. **Cable runs** with no length on the drawings use Qty `Lot` and "length TBD".
6. **Owner-furnished (OFE)** items stay on the list for coordination. Use `"furnished": "Owner (OFE)"`; the row turns blue and is not priced.
7. **Licensing lines:** list every license the design needs (conferencing room licenses, DSP feature/scaling licenses, streaming/Dante licenses). Show included licenses as "- included" and licenses that aren't needed as Qty 0 "- NOT REQUIRED" so the estimator sees they were considered. Note who furnishes each one.
8. Tags must match the drawings and the SOW exactly (`CDC-01`, `DSP-01`, `MIC-01`...).

## Workbook format (produced by the script)

- **Tabs:** `Summary` plus one tab per room.
- **Room tab columns:** Item, Tag, Qty, Manufacturer, Model / Part No., Description, Furnished By, What's in the Box, Notes / Source, Unit Price, Extended.
- **Optional section rows:** Equipment, Licensing, Cable & Infrastructure.
- **Room tab layout:** branded header (logo, company | doc set | title, source drawing, owner/address/project no./prepared by/date), red rule, frozen header row, autofilter, room subtotal formula, standard notes, landscape fit-to-width, "Page X of Y" footer.
- **Summary tab:** one row per room (system, source drawing, line-item count, TBD count, subtotal link), total, color legend, Basis of BoM, "Manufacturer sources checked <date>" list.
- **Colors:** yellow `FFF2CC` = TBD / confirm before order; blue `E7EEF7` = owner-furnished.

## Procedure

1. **Read the drawings.** Use the latest revision of each sheet. Inventory every tagged device, every cable/bus, every "(INCLUDED)" or "(OFE)" callout, and keynotes that imply parts (mounts, licenses, kits).
2. **Research each part** on the manufacturer site: exact order code / material number, description, power (PoE class), what's in the box, what's sold separately (mounts, licenses, power supplies). Capture the URL or document title.
3. **Fill the JSON input** from `templates/bom_input.example.json`: one `rooms[]` entry per room/tab and one `items[]` entry per line. Use `section` to group lines. Put box contents in `in_box`, citations in `source`, and drawing references in `notes`. Put project facts in `project`, drawing revisions in `basis`, and URLs/documents in `sources`.
4. **Run:** `python scripts/build_bom.py <input>.json -o <DOCSET>-BoM.xlsx`. The script prints line/TBD counts per room and a warning for any manufacturer line with no `source`. Fix the warnings or mark the line TBD.
5. **Check:** open the workbook, or render it to PDF with `soffice --headless --convert-to pdf`. Confirm the tabs, frozen header, filters, yellow/blue rows, blank Unit Price, and that Extended fills in when a test price is typed.
6. **Deliver.** Write the input JSON with `write_file`, run the script from the terminal, then show the result with `::preview{file="..."}` on its own line (preview the PDF render for a visual check; the .xlsx workbook is the deliverable). Report TBD/open-item counts.

## Packaging a design package

When the BoM ships with drawings and a SOW:

1. One folder per branded solution (for example `Crestron/`, `QSC-Q-SYS/`), each with `Drawings/` (PDF), `BoM/` (xlsx) and `Scope of Work/` (docx). Latest revisions only.
2. Fill `templates/package_input.example.json` and run `python scripts/package_deliverables.py package.json -o <outdir>`. It copies the files, writes `README.txt` (contents and BoM conventions) and zips the package. A missing file is a warning and a non-zero exit.

## Pitfalls

- Guessing a SKU or finish code instead of marking it TBD
- Pricing anything, even "typical" prices
- Forgetting mounts, power supplies or licenses that are "sold separately"
- Charging for cables that ship in the box
- Tags or quantities that don't match the drawing or the SOW
- Mixing revisions: basis lines must name the drawing revision the BoM was built from

## Output paths

Save under the project folder if the user has one, else the current working directory:

```
<DOCSET>-BoM.xlsx
<DOCSET>-bom-input.json        (keep it; re-run after drawing revisions)
```

Requirements: Python 3 with `openpyxl` (`pip install openpyxl`; `Pillow` optional, keeps the logo aspect ratio). LibreOffice (`soffice`) is optional, for PDF render checks.
